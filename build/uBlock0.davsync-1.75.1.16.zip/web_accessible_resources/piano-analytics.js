self.pa = {
    getVisitorId() {
    },
    sendEvent() {
    },
};
